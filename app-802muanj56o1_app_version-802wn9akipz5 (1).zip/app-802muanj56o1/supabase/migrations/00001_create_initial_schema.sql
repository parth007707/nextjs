/*
# Create Initial E-commerce Schema

1. New Tables
- `profiles`
    - `id` (uuid, primary key, references auth.users)
    - `email` (text, unique)
    - `full_name` (text)
    - `role` (user_role, default: 'user', not null)
    - `created_at` (timestamptz, default: now())

- `products`
    - `id` (uuid, primary key)
    - `name` (text, not null)
    - `description` (text)
    - `price` (numeric, not null)
    - `category` (text, not null)
    - `image_url` (text)
    - `stock` (integer, default: 0)
    - `featured` (boolean, default: false)
    - `created_at` (timestamptz, default: now())

- `cart_items`
    - `id` (uuid, primary key)
    - `user_id` (uuid, references profiles)
    - `product_id` (uuid, references products)
    - `quantity` (integer, not null)
    - `created_at` (timestamptz, default: now())

- `orders`
    - `id` (uuid, primary key)
    - `user_id` (uuid, references profiles, nullable for guest checkout)
    - `items` (jsonb, not null)
    - `total_amount` (numeric, not null)
    - `currency` (text, default: 'usd')
    - `status` (order_status, default: 'pending')
    - `stripe_session_id` (text, unique)
    - `stripe_payment_intent_id` (text)
    - `customer_email` (text)
    - `customer_name` (text)
    - `completed_at` (timestamptz)
    - `created_at` (timestamptz, default: now())
    - `updated_at` (timestamptz, default: now())

2. Security
- Enable RLS on all tables
- Profiles: Users can view/update own profile; admins have full access
- Products: Public read access; admin-only write access
- Cart: Users can manage their own cart items
- Orders: Users can view their own orders; service role can manage all

3. Helper Functions
- `is_admin`: Check if user has admin role
- `handle_new_user`: Auto-create profile on user signup

4. Initial Data
- Insert sample products for demonstration
*/

-- Create ENUM types
CREATE TYPE user_role AS ENUM ('user', 'admin');
CREATE TYPE order_status AS ENUM ('pending', 'completed', 'cancelled', 'refunded');

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE,
  full_name text,
  role user_role DEFAULT 'user'::user_role NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price numeric(10,2) NOT NULL CHECK (price >= 0),
  category text NOT NULL,
  image_url text,
  stock integer DEFAULT 0 CHECK (stock >= 0),
  featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create cart_items table
CREATE TABLE IF NOT EXISTS cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  quantity integer NOT NULL CHECK (quantity > 0),
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, product_id)
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  items jsonb NOT NULL,
  total_amount numeric(12,2) NOT NULL CHECK (total_amount >= 0),
  currency text NOT NULL DEFAULT 'usd',
  status order_status NOT NULL DEFAULT 'pending'::order_status,
  stripe_session_id text UNIQUE,
  stripe_payment_intent_id text,
  customer_email text,
  customer_name text,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX idx_products_category ON products(category);
CREATE INDEX idx_products_featured ON products(featured);
CREATE INDEX idx_cart_user_id ON cart_items(user_id);
CREATE INDEX idx_orders_user_id ON orders(user_id);
CREATE INDEX idx_orders_stripe_session_id ON orders(stripe_session_id);
CREATE INDEX idx_orders_status ON orders(status);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE cart_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Helper function to check admin role
CREATE OR REPLACE FUNCTION is_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = 'admin'::user_role
  );
$$;

-- Profiles policies
CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id) 
  WITH CHECK (role IS NOT DISTINCT FROM (SELECT role FROM profiles WHERE id = auth.uid()));

CREATE POLICY "Admins have full access to profiles" ON profiles
  FOR ALL USING (is_admin(auth.uid()));

-- Products policies (public read, admin write)
CREATE POLICY "Anyone can view products" ON products
  FOR SELECT USING (true);

CREATE POLICY "Admins can insert products" ON products
  FOR INSERT WITH CHECK (is_admin(auth.uid()));

CREATE POLICY "Admins can update products" ON products
  FOR UPDATE USING (is_admin(auth.uid()));

CREATE POLICY "Admins can delete products" ON products
  FOR DELETE USING (is_admin(auth.uid()));

-- Cart policies
CREATE POLICY "Users can view own cart" ON cart_items
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert to own cart" ON cart_items
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own cart" ON cart_items
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete from own cart" ON cart_items
  FOR DELETE USING (auth.uid() = user_id);

-- Orders policies
CREATE POLICY "Users can view own orders" ON orders
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage orders" ON orders
  FOR ALL USING (auth.jwt()->>'role' = 'service_role');

-- Trigger function to handle new user creation
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
BEGIN
  SELECT COUNT(*) INTO user_count FROM profiles;
  INSERT INTO profiles (id, email, role)
  VALUES (
    NEW.id,
    NEW.email,
    CASE WHEN user_count = 0 THEN 'admin'::user_role ELSE 'user'::user_role END
  );
  RETURN NEW;
END;
$$;

-- Create trigger for new user
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  WHEN (OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL)
  EXECUTE FUNCTION handle_new_user();

-- Insert sample products
INSERT INTO products (name, description, price, category, image_url, stock, featured) VALUES
('Classic White Tee', 'Premium cotton t-shirt with TIXY logo', 29.99, 'tops', 'placeholder-white-tee.jpg', 50, true),
('Black Denim Jeans', 'Slim fit black denim jeans', 79.99, 'bottoms', 'placeholder-black-jeans.jpg', 30, true),
('Summer Floral Dress', 'Elegant floral print summer dress', 89.99, 'dresses', 'placeholder-floral-dress.jpg', 20, true),
('Leather Crossbody Bag', 'Genuine leather crossbody bag', 129.99, 'accessories', 'placeholder-leather-bag.jpg', 15, true),
('Striped Button-Up Shirt', 'Classic striped button-up shirt', 49.99, 'tops', 'placeholder-striped-shirt.jpg', 40, false),
('High-Waist Trousers', 'Professional high-waist trousers', 69.99, 'bottoms', 'placeholder-trousers.jpg', 25, false),
('Evening Cocktail Dress', 'Sophisticated evening cocktail dress', 149.99, 'dresses', 'placeholder-cocktail-dress.jpg', 10, false),
('Gold Chain Necklace', 'Elegant gold-plated chain necklace', 39.99, 'accessories', 'placeholder-necklace.jpg', 50, false);