import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import ProductCard from '@/components/products/ProductCard';
import { api } from '@/db/api';
import { supabase } from '@/db/supabase';
import type { Product } from '@/types/types';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';

export default function ProductsPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [category, setCategory] = useState(searchParams.get('category') || 'all');
  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    const categoryParam = searchParams.get('category');
    const searchParam = searchParams.get('search');
    
    if (categoryParam) setCategory(categoryParam);
    if (searchParam) setSearchQuery(searchParam);
    
    loadProducts(categoryParam || 'all', searchParam || '');
  }, [searchParams]);

  const loadProducts = async (cat: string, search: string) => {
    try {
      setLoading(true);
      let result: Product[];
      
      if (search) {
        result = await api.searchProducts(search);
      } else {
        result = await api.getProducts(cat === 'all' ? undefined : cat);
      }
      
      setProducts(result);
    } catch (error) {
      console.error('Failed to load products:', error);
      toast({
        title: 'Failed to load products',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCategoryChange = (value: string) => {
    setCategory(value);
    setSearchQuery('');
    const params = new URLSearchParams();
    if (value !== 'all') {
      params.set('category', value);
    }
    setSearchParams(params);
  };

  const handleAddToCart = async (product: Product) => {
    if (!user) {
      toast({
        title: 'Please sign in',
        description: 'You need to sign in to add items to cart',
      });
      navigate('/login');
      return;
    }

    try {
      await api.addToCart(user.id, product.id, 1);
      toast({
        title: 'Added to cart',
        description: `${product.name} has been added to your cart`,
      });
    } catch (error) {
      toast({
        title: 'Failed to add to cart',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="min-h-screen">
      <div className="bg-muted py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold mb-4">
            {searchQuery ? `Search Results for "${searchQuery}"` : 'Shop All Products'}
          </h1>
          <p className="text-muted-foreground">
            Discover our complete collection of premium fashion
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col xl:flex-row gap-4 mb-8">
          <Select value={category} onValueChange={handleCategoryChange}>
            <SelectTrigger className="w-full xl:w-64">
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="tops">Tops</SelectItem>
              <SelectItem value="bottoms">Bottoms</SelectItem>
              <SelectItem value="dresses">Dresses</SelectItem>
              <SelectItem value="accessories">Accessories</SelectItem>
            </SelectContent>
          </Select>

          {searchQuery && (
            <Button
              variant="outline"
              onClick={() => {
                setSearchQuery('');
                setSearchParams({});
              }}
            >
              Clear Search
            </Button>
          )}
        </div>

        {loading ? (
          <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="space-y-4">
                <Skeleton className="aspect-square w-full bg-muted" />
                <Skeleton className="h-6 w-3/4 bg-muted" />
                <Skeleton className="h-4 w-1/2 bg-muted" />
              </div>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-xl text-muted-foreground mb-4">
              No products found
            </p>
            <Button onClick={() => {
              setCategory('all');
              setSearchQuery('');
              setSearchParams({});
            }}>
              View All Products
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
            {products.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={handleAddToCart}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
