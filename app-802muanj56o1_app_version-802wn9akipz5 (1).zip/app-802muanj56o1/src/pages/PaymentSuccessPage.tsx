import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { useToast } from '@/hooks/use-toast';

export default function PaymentSuccessPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchParams] = useSearchParams();
  const [verifying, setVerifying] = useState(true);
  const [verified, setVerified] = useState(false);
  const [paymentDetails, setPaymentDetails] = useState<any>(null);

  useEffect(() => {
    const sessionId = searchParams.get('session_id');
    if (!sessionId) {
      toast({
        title: 'Invalid payment session',
        variant: 'destructive',
      });
      navigate('/cart');
      return;
    }

    verifyPayment(sessionId);
  }, [searchParams, navigate, toast]);

  const verifyPayment = async (sessionId: string) => {
    try {
      setVerifying(true);
      const { data, error } = await supabase.functions.invoke('verify_stripe_payment', {
        body: JSON.stringify({ sessionId }),
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || 'Failed to verify payment');
      }

      if (data?.data?.verified) {
        setVerified(true);
        setPaymentDetails(data.data);
        toast({
          title: 'Payment successful',
          description: 'Your order has been confirmed',
        });
      } else {
        setVerified(false);
        toast({
          title: 'Payment not completed',
          description: 'Please try again or contact support',
          variant: 'destructive',
        });
      }
    } catch (error: any) {
      console.error('Payment verification error:', error);
      setVerified(false);
      toast({
        title: 'Verification failed',
        description: error.message || 'Could not verify payment',
        variant: 'destructive',
      });
    } finally {
      setVerifying(false);
    }
  };

  if (verifying) {
    return (
      <div className="container mx-auto px-4 py-16">
        <Card className="max-w-md mx-auto">
          <CardContent className="p-8 text-center space-y-4">
            <Loader2 className="h-16 w-16 mx-auto animate-spin text-gold" />
            <h2 className="text-2xl font-bold">Verifying Payment</h2>
            <p className="text-muted-foreground">
              Please wait while we confirm your payment...
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <Card className="max-w-md mx-auto">
        <CardContent className="p-8 text-center space-y-6">
          {verified ? (
            <>
              <CheckCircle2 className="h-16 w-16 mx-auto text-green-500" />
              <h2 className="text-2xl font-bold">Payment Successful!</h2>
              <p className="text-muted-foreground">
                Thank you for your purchase. Your order has been confirmed.
              </p>
              {paymentDetails && (
                <div className="text-left space-y-2 p-4 bg-muted rounded-lg">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Amount:</span>
                    <span className="font-semibold">
                      ${((paymentDetails.amount || 0) / 100).toFixed(2)} {paymentDetails.currency?.toUpperCase()}
                    </span>
                  </div>
                  {paymentDetails.customerEmail && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Email:</span>
                      <span className="font-semibold">{paymentDetails.customerEmail}</span>
                    </div>
                  )}
                </div>
              )}
              <div className="space-y-2">
                <Button className="w-full" onClick={() => navigate('/orders')}>
                  View Orders
                </Button>
                <Button variant="outline" className="w-full" onClick={() => navigate('/products')}>
                  Continue Shopping
                </Button>
              </div>
            </>
          ) : (
            <>
              <XCircle className="h-16 w-16 mx-auto text-destructive" />
              <h2 className="text-2xl font-bold">Payment Not Completed</h2>
              <p className="text-muted-foreground">
                Your payment could not be verified. Please check your order history or try again.
              </p>
              <div className="space-y-2">
                <Button className="w-full" onClick={() => navigate('/orders')}>
                  View Orders
                </Button>
                <Button variant="outline" className="w-full" onClick={() => navigate('/cart')}>
                  Back to Cart
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
