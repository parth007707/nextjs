import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, Package } from 'lucide-react';
import { api } from '@/db/api';
import { supabase } from '@/db/supabase';
import type { Order } from '@/types/types';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';

export default function OrdersPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [refreshing, setRefreshing] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session?.user) {
        navigate('/login');
        return;
      }
      setUser(session.user);
      loadOrders(session.user.id);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session?.user) {
        navigate('/login');
        return;
      }
      setUser(session.user);
      loadOrders(session.user.id);
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const loadOrders = async (userId: string) => {
    try {
      setLoading(true);
      const data = await api.getUserOrders(userId);
      setOrders(data);
    } catch (error) {
      console.error('Failed to load orders:', error);
      toast({
        title: 'Failed to load orders',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const refreshOrderStatus = async (order: Order) => {
    if (!order.stripe_session_id) return;

    setRefreshing(order.id);
    try {
      const { data, error } = await supabase.functions.invoke('verify_stripe_payment', {
        body: JSON.stringify({ sessionId: order.stripe_session_id }),
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || 'Failed to verify payment');
      }

      if (data?.data?.verified && user) {
        await loadOrders(user.id);
        toast({
          title: 'Order status updated',
        });
      }
    } catch (error: any) {
      toast({
        title: 'Failed to refresh status',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setRefreshing(null);
    }
  };

  const retryPayment = async (order: Order) => {
    if (!order.stripe_session_id) return;

    try {
      const items = order.items.map(item => ({
        name: item.name,
        price: item.price / 100,
        quantity: item.quantity,
        image_url: item.image_url,
      }));

      const { data, error } = await supabase.functions.invoke('create_stripe_checkout', {
        body: JSON.stringify({ items }),
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || 'Failed to create checkout session');
      }

      if (data?.data?.url) {
        window.open(data.data.url, '_blank');
        toast({
          title: 'Redirecting to checkout',
        });
      }
    } catch (error: any) {
      toast({
        title: 'Failed to retry payment',
        description: error.message,
        variant: 'destructive',
      });
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      pending: 'secondary',
      completed: 'default',
      cancelled: 'destructive',
      refunded: 'outline',
    };

    return (
      <Badge variant={variants[status] || 'default'}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Skeleton className="h-10 w-48 mb-8 bg-muted" />
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-48 w-full bg-muted" />
          ))}
        </div>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <Package className="h-24 w-24 mx-auto mb-4 text-muted-foreground" />
        <h2 className="text-2xl font-bold mb-4">No orders yet</h2>
        <p className="text-muted-foreground mb-8">
          Start shopping to see your orders here
        </p>
        <Button onClick={() => navigate('/products')}>
          Browse Products
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Order History</h1>

      <div className="space-y-4">
        {orders.map((order) => (
          <Card key={order.id}>
            <CardHeader>
              <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4">
                <div>
                  <CardTitle className="text-lg">
                    Order #{order.id.slice(0, 8)}
                  </CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">
                    {new Date(order.created_at).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusBadge(order.status)}
                  {order.status === 'pending' && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => refreshOrderStatus(order)}
                      disabled={refreshing === order.id}
                    >
                      <RefreshCw className={`h-4 w-4 mr-2 ${refreshing === order.id ? 'animate-spin' : ''}`} />
                      Refresh Status
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {order.items.map((item, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">{item.name}</p>
                      <p className="text-sm text-muted-foreground">
                        Quantity: {item.quantity} × ${(item.price / 100).toFixed(2)}
                      </p>
                    </div>
                    <p className="font-semibold">
                      ${((item.price * item.quantity) / 100).toFixed(2)}
                    </p>
                  </div>
                ))}
              </div>

              <div className="border-t border-border mt-4 pt-4 flex justify-between items-center">
                <span className="font-bold">Total</span>
                <span className="text-xl font-bold gold-text">
                  ${order.total_amount.toFixed(2)}
                </span>
              </div>

              {order.status === 'pending' && (
                <div className="mt-4">
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => retryPayment(order)}
                  >
                    Complete Payment
                  </Button>
                </div>
              )}

              {order.completed_at && (
                <p className="text-sm text-muted-foreground mt-4">
                  Completed on {new Date(order.completed_at).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </p>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
