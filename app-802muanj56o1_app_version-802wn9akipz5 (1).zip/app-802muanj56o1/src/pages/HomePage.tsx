import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import ProductCard from '@/components/products/ProductCard';
import { api } from '@/db/api';
import { supabase } from '@/db/supabase';
import type { Product } from '@/types/types';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { ExternalLink } from 'lucide-react';

export default function HomePage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    loadFeaturedProducts();

    return () => subscription.unsubscribe();
  }, []);

  const loadFeaturedProducts = async () => {
    try {
      setLoading(true);
      const products = await api.getFeaturedProducts();
      setFeaturedProducts(products);
    } catch (error) {
      console.error('Failed to load featured products:', error);
      toast({
        title: 'Failed to load products',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = async (product: Product) => {
    if (!user) {
      toast({
        title: 'Please sign in',
        description: 'You need to sign in to add items to cart',
      });
      navigate('/login');
      return;
    }

    try {
      await api.addToCart(user.id, product.id, 1);
      toast({
        title: 'Added to cart',
        description: `${product.name} has been added to your cart`,
      });
    } catch (error) {
      toast({
        title: 'Failed to add to cart',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="min-h-screen">
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden bg-gradient-to-br from-background via-muted to-background">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1920')] bg-cover bg-center opacity-20" />
        <div className="relative z-10 text-center space-y-6 px-4">
          <h1 className="text-5xl xl:text-7xl font-bold tracking-tight">
            Welcome to <span className="gold-text">TIXY</span>
          </h1>
          <p className="text-xl xl:text-2xl text-muted-foreground max-w-2xl mx-auto">
            Discover premium fashion that defines your unique style
          </p>
          <div className="flex flex-col xl:flex-row gap-4 justify-center items-center">
            <Button size="lg" onClick={() => navigate('/products')} className="shadow-gold">
              Shop Now
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => window.open('https://www.amazon.com', '_blank')}
            >
              <ExternalLink className="mr-2 h-5 w-5" />
              Visit Amazon Store
            </Button>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl xl:text-4xl font-bold mb-4">Featured Collection</h2>
          <p className="text-muted-foreground">
            Handpicked styles for the season
          </p>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="space-y-4">
                <Skeleton className="aspect-square w-full bg-muted" />
                <Skeleton className="h-6 w-3/4 bg-muted" />
                <Skeleton className="h-4 w-1/2 bg-muted" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={handleAddToCart}
              />
            ))}
          </div>
        )}

        <div className="text-center mt-12">
          <Button size="lg" variant="outline" onClick={() => navigate('/products')}>
            View All Products
          </Button>
        </div>
      </section>

      <section className="bg-muted py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 text-center">
            <div className="space-y-3">
              <div className="text-4xl">✨</div>
              <h3 className="text-xl font-semibold">Premium Quality</h3>
              <p className="text-muted-foreground">
                Carefully selected materials for lasting comfort
              </p>
            </div>
            <div className="space-y-3">
              <div className="text-4xl">🚚</div>
              <h3 className="text-xl font-semibold">Fast Shipping</h3>
              <p className="text-muted-foreground">
                Quick and reliable delivery to your doorstep
              </p>
            </div>
            <div className="space-y-3">
              <div className="text-4xl">💳</div>
              <h3 className="text-xl font-semibold">Secure Payment</h3>
              <p className="text-muted-foreground">
                Safe and encrypted payment processing
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
