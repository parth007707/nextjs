import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Shield } from 'lucide-react';
import { api } from '@/db/api';
import { supabase } from '@/db/supabase';
import type { Profile } from '@/types/types';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';

export default function AdminPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [currentProfile, setCurrentProfile] = useState<Profile | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session?.user) {
        navigate('/login');
        return;
      }
      setCurrentUser(session.user);
      checkAdminAccess(session.user.id);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session?.user) {
        navigate('/login');
        return;
      }
      setCurrentUser(session.user);
      checkAdminAccess(session.user.id);
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const checkAdminAccess = async (userId: string) => {
    try {
      const profile = await api.getProfile(userId);
      if (!profile || profile.role !== 'admin') {
        toast({
          title: 'Access denied',
          description: 'You do not have admin privileges',
          variant: 'destructive',
        });
        navigate('/');
        return;
      }
      setCurrentProfile(profile);
      loadProfiles();
    } catch (error) {
      console.error('Failed to check admin access:', error);
      navigate('/');
    }
  };

  const loadProfiles = async () => {
    try {
      setLoading(true);
      const data = await api.getAllProfiles();
      setProfiles(data);
    } catch (error) {
      console.error('Failed to load profiles:', error);
      toast({
        title: 'Failed to load users',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRoleChange = async (userId: string, newRole: 'user' | 'admin') => {
    if (userId === currentUser?.id) {
      toast({
        title: 'Cannot change your own role',
        variant: 'destructive',
      });
      return;
    }

    try {
      await api.updateUserRole(userId, newRole);
      setProfiles(profiles.map(p => 
        p.id === userId ? { ...p, role: newRole } : p
      ));
      toast({
        title: 'Role updated successfully',
      });
    } catch (error) {
      toast({
        title: 'Failed to update role',
        variant: 'destructive',
      });
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Skeleton className="h-10 w-48 mb-8 bg-muted" />
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-24 w-full bg-muted" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center gap-3 mb-8">
        <Shield className="h-8 w-8 gold-text" />
        <h1 className="text-3xl font-bold">Admin Panel</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>User Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {profiles.map((profile) => (
              <div
                key={profile.id}
                className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4 p-4 border border-border rounded-lg"
              >
                <div className="flex-1">
                  <p className="font-semibold">{profile.email || 'No email'}</p>
                  <p className="text-sm text-muted-foreground">
                    {profile.full_name || 'No name'}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    ID: {profile.id.slice(0, 8)}...
                  </p>
                </div>

                <div className="flex items-center gap-4">
                  <Select
                    value={profile.role}
                    onValueChange={(value: 'user' | 'admin') => handleRoleChange(profile.id, value)}
                    disabled={profile.id === currentUser?.id}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="user">User</SelectItem>
                      <SelectItem value="admin">Admin</SelectItem>
                    </SelectContent>
                  </Select>

                  {profile.id === currentUser?.id && (
                    <span className="text-xs text-muted-foreground">(You)</span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {profiles.length === 0 && (
            <p className="text-center text-muted-foreground py-8">
              No users found
            </p>
          )}
        </CardContent>
      </Card>

      <div className="mt-8">
        <Card>
          <CardHeader>
            <CardTitle>Admin Information</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              The first user to register automatically becomes an admin. You can manage user roles from this panel.
            </p>
            <div className="space-y-2 text-sm">
              <p><strong>Total Users:</strong> {profiles.length}</p>
              <p><strong>Admins:</strong> {profiles.filter(p => p.role === 'admin').length}</p>
              <p><strong>Regular Users:</strong> {profiles.filter(p => p.role === 'user').length}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
