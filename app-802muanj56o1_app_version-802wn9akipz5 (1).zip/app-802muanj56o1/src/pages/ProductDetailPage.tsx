import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ShoppingCart, Minus, Plus } from 'lucide-react';
import { api } from '@/db/api';
import { supabase } from '@/db/supabase';
import type { Product } from '@/types/types';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    if (id) {
      loadProduct(id);
    }

    return () => subscription.unsubscribe();
  }, [id]);

  const loadProduct = async (productId: string) => {
    try {
      setLoading(true);
      const data = await api.getProduct(productId);
      if (!data) {
        toast({
          title: 'Product not found',
          variant: 'destructive',
        });
        navigate('/products');
        return;
      }
      setProduct(data);
    } catch (error) {
      console.error('Failed to load product:', error);
      toast({
        title: 'Failed to load product',
        variant: 'destructive',
      });
      navigate('/products');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = async () => {
    if (!user) {
      toast({
        title: 'Please sign in',
        description: 'You need to sign in to add items to cart',
      });
      navigate('/login');
      return;
    }

    if (!product) return;

    try {
      await api.addToCart(user.id, product.id, quantity);
      toast({
        title: 'Added to cart',
        description: `${quantity} x ${product.name} added to your cart`,
      });
      navigate('/cart');
    } catch (error) {
      toast({
        title: 'Failed to add to cart',
        variant: 'destructive',
      });
    }
  };

  const incrementQuantity = () => {
    if (product && quantity < product.stock) {
      setQuantity(quantity + 1);
    }
  };

  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
          <Skeleton className="aspect-square w-full bg-muted" />
          <div className="space-y-4">
            <Skeleton className="h-10 w-3/4 bg-muted" />
            <Skeleton className="h-6 w-1/4 bg-muted" />
            <Skeleton className="h-24 w-full bg-muted" />
            <Skeleton className="h-12 w-full bg-muted" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return null;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        <div className="aspect-square overflow-hidden rounded-lg bg-muted">
          <img
            src={product.image_url || 'https://via.placeholder.com/800'}
            alt={product.name}
            className="h-full w-full object-cover"
          />
        </div>

        <div className="space-y-6">
          <div>
            <h1 className="text-3xl xl:text-4xl font-bold mb-2">{product.name}</h1>
            <p className="text-sm text-muted-foreground uppercase tracking-wide">
              {product.category}
            </p>
          </div>

          <div className="text-3xl font-bold gold-text">
            ${product.price.toFixed(2)}
          </div>

          <p className="text-muted-foreground leading-relaxed">
            {product.description || 'No description available.'}
          </p>

          <Card>
            <CardContent className="p-6 space-y-4">
              <div>
                <Label htmlFor="quantity">Quantity</Label>
                <div className="flex items-center gap-2 mt-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={decrementQuantity}
                    disabled={quantity <= 1}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <Input
                    id="quantity"
                    type="number"
                    min="1"
                    max={product.stock}
                    value={quantity}
                    onChange={(e) => {
                      const val = parseInt(e.target.value);
                      if (!isNaN(val) && val >= 1 && val <= product.stock) {
                        setQuantity(val);
                      }
                    }}
                    className="w-20 text-center"
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={incrementQuantity}
                    disabled={quantity >= product.stock}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  {product.stock} items in stock
                </p>
              </div>

              <Button
                className="w-full"
                size="lg"
                onClick={handleAddToCart}
                disabled={product.stock === 0}
              >
                <ShoppingCart className="mr-2 h-5 w-5" />
                {product.stock === 0 ? 'Out of Stock' : 'Add to Cart'}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
