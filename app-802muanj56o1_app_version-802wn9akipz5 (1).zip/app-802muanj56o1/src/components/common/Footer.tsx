import { Link } from 'react-router-dom';
import { ExternalLink } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t border-border bg-card">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">TIXY</h3>
            <p className="text-sm text-muted-foreground">
              Premium fashion clothing for the modern individual. Discover your style with TIXY.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold mb-4">Shop</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link to="/products?category=tops" className="transition-smooth hover:text-gold">
                  Tops
                </Link>
              </li>
              <li>
                <Link to="/products?category=bottoms" className="transition-smooth hover:text-gold">
                  Bottoms
                </Link>
              </li>
              <li>
                <Link to="/products?category=dresses" className="transition-smooth hover:text-gold">
                  Dresses
                </Link>
              </li>
              <li>
                <Link to="/products?category=accessories" className="transition-smooth hover:text-gold">
                  Accessories
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold mb-4">Customer Service</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link to="/orders" className="transition-smooth hover:text-gold">
                  Order History
                </Link>
              </li>
              <li>
                <Link to="/cart" className="transition-smooth hover:text-gold">
                  Shopping Cart
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold mb-4">Extended Inventory</h4>
            <p className="text-sm text-muted-foreground mb-3">
              Looking for more options? Visit our Amazon store for extended product range.
            </p>
            <a
              href="https://www.amazon.com"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center text-sm font-medium text-gold transition-smooth hover:text-gold-dark"
            >
              Shop on Amazon
              <ExternalLink className="ml-1 h-4 w-4" />
            </a>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-border text-center text-sm text-muted-foreground">
          <p>{currentYear} TIXY</p>
        </div>
      </div>
    </footer>
  );
}
