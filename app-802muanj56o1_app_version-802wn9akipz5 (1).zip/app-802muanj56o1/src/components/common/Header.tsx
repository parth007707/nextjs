import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, User, LogOut, Search, Menu, X, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { supabase } from '@/db/supabase';
import { useEffect, useState } from 'react';
import { api } from '@/db/api';
import type { Profile } from '@/types/types';
import { useToast } from '@/hooks/use-toast';

export default function Header() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [cartCount, setCartCount] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        loadProfile(session.user.id);
        loadCartCount(session.user.id);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        loadProfile(session.user.id);
        loadCartCount(session.user.id);
      } else {
        setProfile(null);
        setCartCount(0);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const loadProfile = async (userId: string) => {
    try {
      const data = await api.getProfile(userId);
      setProfile(data);
    } catch (error) {
      console.error('Failed to load profile:', error);
    }
  };

  const loadCartCount = async (userId: string) => {
    try {
      const items = await api.getCartItems(userId);
      setCartCount(items.reduce((sum, item) => sum + item.quantity, 0));
    } catch (error) {
      console.error('Failed to load cart count:', error);
    }
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: 'Logged out successfully',
      });
      navigate('/');
    } catch (error) {
      toast({
        title: 'Logout failed',
        variant: 'destructive',
      });
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery)}`);
      setSearchQuery('');
      setMobileMenuOpen(false);
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <span className="text-2xl font-bold tracking-tight">
              TIXY
            </span>
          </Link>

          <nav className="hidden xl:flex items-center space-x-6">
            <Link to="/" className="text-sm font-medium transition-smooth hover:text-gold">
              Home
            </Link>
            <Link to="/products" className="text-sm font-medium transition-smooth hover:text-gold">
              Shop
            </Link>
            <Link to="/products?category=tops" className="text-sm font-medium transition-smooth hover:text-gold">
              Tops
            </Link>
            <Link to="/products?category=bottoms" className="text-sm font-medium transition-smooth hover:text-gold">
              Bottoms
            </Link>
            <Link to="/products?category=dresses" className="text-sm font-medium transition-smooth hover:text-gold">
              Dresses
            </Link>
            <Link to="/products?category=accessories" className="text-sm font-medium transition-smooth hover:text-gold">
              Accessories
            </Link>
          </nav>

          <div className="hidden xl:flex items-center space-x-4">
            <form onSubmit={handleSearch} className="relative">
              <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search products..."
                className="w-64 pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </form>

            {user ? (
              <>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => navigate('/cart')}
                  className="relative"
                >
                  <ShoppingCart className="h-5 w-5" />
                  {cartCount > 0 && (
                    <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-gold text-xs font-bold text-primary">
                      {cartCount}
                    </span>
                  )}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => navigate('/orders')}
                >
                  <User className="h-5 w-5" />
                </Button>
                {profile?.role === 'admin' && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => navigate('/admin')}
                  >
                    <Shield className="h-5 w-5" />
                  </Button>
                )}
                <Button variant="ghost" size="icon" onClick={handleLogout}>
                  <LogOut className="h-5 w-5" />
                </Button>
              </>
            ) : (
              <Button onClick={() => navigate('/login')}>
                Sign In
              </Button>
            )}
          </div>

          <Button
            variant="ghost"
            size="icon"
            className="xl:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>

        {mobileMenuOpen && (
          <div className="xl:hidden border-t border-border py-4 space-y-4">
            <form onSubmit={handleSearch} className="relative">
              <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search products..."
                className="w-full pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </form>

            <nav className="flex flex-col space-y-3">
              <Link
                to="/"
                className="text-sm font-medium transition-smooth hover:text-gold"
                onClick={() => setMobileMenuOpen(false)}
              >
                Home
              </Link>
              <Link
                to="/products"
                className="text-sm font-medium transition-smooth hover:text-gold"
                onClick={() => setMobileMenuOpen(false)}
              >
                Shop
              </Link>
              <Link
                to="/products?category=tops"
                className="text-sm font-medium transition-smooth hover:text-gold"
                onClick={() => setMobileMenuOpen(false)}
              >
                Tops
              </Link>
              <Link
                to="/products?category=bottoms"
                className="text-sm font-medium transition-smooth hover:text-gold"
                onClick={() => setMobileMenuOpen(false)}
              >
                Bottoms
              </Link>
              <Link
                to="/products?category=dresses"
                className="text-sm font-medium transition-smooth hover:text-gold"
                onClick={() => setMobileMenuOpen(false)}
              >
                Dresses
              </Link>
              <Link
                to="/products?category=accessories"
                className="text-sm font-medium transition-smooth hover:text-gold"
                onClick={() => setMobileMenuOpen(false)}
              >
                Accessories
              </Link>
            </nav>

            <div className="flex flex-col space-y-2 pt-4 border-t border-border">
              {user ? (
                <>
                  <Button
                    variant="outline"
                    onClick={() => {
                      navigate('/cart');
                      setMobileMenuOpen(false);
                    }}
                  >
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    Cart ({cartCount})
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      navigate('/orders');
                      setMobileMenuOpen(false);
                    }}
                  >
                    <User className="h-4 w-4 mr-2" />
                    Orders
                  </Button>
                  {profile?.role === 'admin' && (
                    <Button
                      variant="outline"
                      onClick={() => {
                        navigate('/admin');
                        setMobileMenuOpen(false);
                      }}
                    >
                      <Shield className="h-4 w-4 mr-2" />
                      Admin
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    onClick={() => {
                      handleLogout();
                      setMobileMenuOpen(false);
                    }}
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </Button>
                </>
              ) : (
                <Button
                  onClick={() => {
                    navigate('/login');
                    setMobileMenuOpen(false);
                  }}
                >
                  Sign In
                </Button>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
